export const GET_AGENTS = "GET_AGENTS";
export const GET_FEATURED_AGENTS = "GET_FEATURED_AGENTS";
export const GET_AGENT = "GET_AGENT";
