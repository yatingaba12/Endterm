import styled from "styled-components/macro";

const Container = styled.div``;

const Content = styled.div`
  overflow-x: auto;
`;

export { Container, Content };
