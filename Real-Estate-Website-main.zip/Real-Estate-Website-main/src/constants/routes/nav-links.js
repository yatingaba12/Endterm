const links = [
  {
    name: "Home",
    to: "/",
  },
  {
    name: "Listing",
    to: "/listing",
  },
  {
    name: "Agents",
    to: "/agents",
  },
  {
    name: "login",
    to: "/login",
  },
];

export default links;
